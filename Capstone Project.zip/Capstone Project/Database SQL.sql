CREATE DATABASE IF NOT EXISTS tcg_market_analysis
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
 
USE tcg_market_analysis;
 
DROP VIEW IF EXISTS v_savings_opportunity;
DROP VIEW IF EXISTS v_market_overview;
DROP VIEW IF EXISTS v_price_tier;
DROP VIEW IF EXISTS v_catalog_depth;
DROP VIEW IF EXISTS v_gap_competitivo;
DROP VIEW IF EXISTS v_pricing_canonico_confrontabili;
DROP VIEW IF EXISTS v_pricing_canonico;
DROP TABLE IF EXISTS price_observations;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS canonical_products;
DROP TABLE IF EXISTS sets;
DROP TABLE IF EXISTS product_types;
DROP TABLE IF EXISTS tcg_games;
DROP TABLE IF EXISTS competitors;
 
CREATE TABLE competitors (
    id                INT UNSIGNED   NOT NULL AUTO_INCREMENT,
    name              VARCHAR(100)   NOT NULL,
    url_base          VARCHAR(255)   NOT NULL,
    market_region     ENUM('EU','USA','GLOBAL') NOT NULL,
    business_type     ENUM('marketplace','retailer') NOT NULL,
    default_currency  CHAR(3)        NOT NULL,    -- ISO 4217 (EUR, USD, GBP)
    PRIMARY KEY (id),
    UNIQUE KEY uk_competitor_name (name)
) ENGINE=InnoDB;
 
CREATE TABLE tcg_games (
    id         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    name       VARCHAR(100)  NOT NULL,
    code       VARCHAR(10)   NOT NULL,    -- es. MTG, PKM, OPCG
    publisher  VARCHAR(100)  NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_tcg_code (code)
) ENGINE=InnoDB;
 
CREATE TABLE sets (
    id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    tcg_game_id   INT UNSIGNED  NOT NULL,
    name          VARCHAR(150)  NOT NULL,
    code          VARCHAR(20)   NOT NULL,    -- es. FDN, OP-08, SV8
    release_date  DATE          NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_set_per_game (tcg_game_id, code),
    KEY ix_sets_release_date (release_date),
    CONSTRAINT fk_sets_tcg
        FOREIGN KEY (tcg_game_id) REFERENCES tcg_games(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;
 
CREATE TABLE product_types (
    id    INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    name  VARCHAR(50)   NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_product_type_name (name)
) ENGINE=InnoDB;
 
CREATE TABLE canonical_products (
    id               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    canonical_key    VARCHAR(255)  NOT NULL,   -- chiave univoca generata da pipeline
    display_name     VARCHAR(255)  NOT NULL,   -- nome user-friendly
    set_id           INT UNSIGNED  NOT NULL,
    product_type_id  INT UNSIGNED  NOT NULL,
    language         VARCHAR(20)   NOT NULL DEFAULT 'English',
    variant          VARCHAR(50)   NULL,        -- es. Standard, Collector, Play
    PRIMARY KEY (id),
    UNIQUE KEY uk_canonical_key (canonical_key),
    KEY ix_canonical_set (set_id),
    KEY ix_canonical_type (product_type_id),
    CONSTRAINT fk_canonical_set
        FOREIGN KEY (set_id) REFERENCES sets(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_canonical_type
        FOREIGN KEY (product_type_id) REFERENCES product_types(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;
 
CREATE TABLE products (
    id                    INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    competitor_id         INT UNSIGNED  NOT NULL,
    canonical_product_id  INT UNSIGNED  NULL,        -- popolato dopo ETL canonicalizzazione
    set_id                INT UNSIGNED  NOT NULL,
    product_type_id       INT UNSIGNED  NOT NULL,
    name                  VARCHAR(255)  NOT NULL,
    external_url          VARCHAR(500)  NOT NULL,
    external_id           VARCHAR(100)  NULL,        -- SKU/product_id sul sito del competitor
    language              VARCHAR(20)   NOT NULL DEFAULT 'English',
    PRIMARY KEY (id),
    UNIQUE KEY uk_product_natural (competitor_id, external_url, language),
    KEY ix_products_competitor (competitor_id),
    KEY ix_products_canonical (canonical_product_id),
    KEY ix_products_set (set_id),
    KEY ix_products_type (product_type_id),
    CONSTRAINT fk_products_competitor
        FOREIGN KEY (competitor_id) REFERENCES competitors(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_products_canonical
        FOREIGN KEY (canonical_product_id) REFERENCES canonical_products(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_products_set
        FOREIGN KEY (set_id) REFERENCES sets(id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_products_type
        FOREIGN KEY (product_type_id) REFERENCES product_types(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;
 
 
CREATE TABLE price_observations (
    id              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
    product_id      INT UNSIGNED     NOT NULL,
    price           DECIMAL(10,2)    NULL,
    original_price  DECIMAL(10,2)    NULL,
    currency        CHAR(3)          NOT NULL,
    listing_status  ENUM('active','inactive') NOT NULL DEFAULT 'active',
    observed_at     DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY ix_price_product (product_id),
    KEY ix_price_observed_at (observed_at),
    KEY ix_price_status (listing_status),
    CONSTRAINT fk_price_product
        FOREIGN KEY (product_id) REFERENCES products(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT chk_price_positive
        CHECK (price IS NULL OR price >= 0),
    CONSTRAINT chk_original_price_positive
        CHECK (original_price IS NULL OR original_price >= 0)
) ENGINE=InnoDB;
 
-- I tre competitor analizzati
INSERT INTO competitors (name, url_base, market_region, business_type, default_currency) VALUES
    ('Miniature Market',  'https://www.miniaturemarket.com', 'USA', 'retailer', 'USD'),
    ('CoolStuffInc',      'https://www.coolstuffinc.com',    'USA', 'retailer', 'USD'),
    ('Il Covo del Nerd',  'https://www.ilcovodelnerd.com',   'EU',  'retailer', 'EUR');
 
 
-- I tre TCG analizzati
INSERT INTO tcg_games (name, code, publisher) VALUES
    ('Magic: The Gathering', 'MTG',  'Wizards of the Coast'),
    ('Pokemon TCG',          'PKM',  'The Pokemon Company'),
    ('One Piece Card Game',  'OPCG', 'Bandai');
 
 
-- Tipologie di prodotto sigillato
INSERT INTO product_types (name) VALUES
    ('Booster Pack'),
    ('Booster Box'),
    ('Booster Display'),
    ('Bundle'),
    ('Starter Deck'),
    ('Commander Deck'),
    ('Elite Trainer Box'),
    ('Collector Box'),
    ('Tin'),
    ('Pre-release Kit'),
    ('Gift Box'),
    ('Accessory'),
    ('Other');
 
CREATE OR REPLACE VIEW v_pricing_canonico AS
SELECT
    cp.id AS canonical_id,
    cp.canonical_key,
    cp.display_name,
    g.name AS gioco,
    s.name AS set_canonico,
    s.code AS set_code,
    s.release_date,
    pt.name AS tipologia,
    cp.language,
    cp.variant,
 
    -- Prezzo medio per competitor in VALUTA NATIVA (tax-included)
    ROUND(AVG(CASE WHEN c.name = 'Miniature Market'  THEN po.price END), 2) AS price_mm_usd,
    ROUND(AVG(CASE WHEN c.name = 'CoolStuffInc'      THEN po.price END), 2) AS price_csi_usd,
    ROUND(AVG(CASE WHEN c.name = 'Il Covo del Nerd'  THEN po.price END), 2) AS price_icn_eur,
 
    -- Prezzo medio in USD TAX-EXCLUDED (per confronto omogeneo)
    -- MM e CSI sono già USD senza tax (USA: sales tax applicata al checkout)
    -- ICN è EUR tax-included: dividiamo per 1.22 (rimuove IVA 22%) poi convertiamo a USD (x 1.13)
    ROUND(AVG(CASE WHEN c.name = 'Miniature Market'  THEN po.price END), 2) AS price_mm_usd_net,
    ROUND(AVG(CASE WHEN c.name = 'CoolStuffInc'      THEN po.price END), 2) AS price_csi_usd_net,
    ROUND(AVG(CASE WHEN c.name = 'Il Covo del Nerd'  THEN po.price / 1.22 * 1.13 END), 2) AS price_icn_usd_net,
 
    -- Numero di prodotti per competitor (profondità catalogo per quel canonical)
    SUM(CASE WHEN c.name = 'Miniature Market'  THEN 1 ELSE 0 END) AS n_prodotti_mm,
    SUM(CASE WHEN c.name = 'CoolStuffInc'      THEN 1 ELSE 0 END) AS n_prodotti_csi,
    SUM(CASE WHEN c.name = 'Il Covo del Nerd'  THEN 1 ELSE 0 END) AS n_prodotti_icn,
 
    -- Numero competitor che lo trattano
    COUNT(DISTINCT p.competitor_id) AS n_competitors
 
FROM canonical_products cp
JOIN sets          s  ON cp.set_id = s.id
JOIN tcg_games     g  ON s.tcg_game_id = g.id
JOIN product_types pt ON cp.product_type_id = pt.id
JOIN products      p  ON p.canonical_product_id = cp.id
JOIN price_observations po ON po.product_id = p.id
JOIN competitors   c  ON p.competitor_id = c.id
WHERE po.price IS NOT NULL
GROUP BY cp.id, cp.canonical_key, cp.display_name, g.name, s.name, s.code, s.release_date,
         pt.name, cp.language, cp.variant;
 
CREATE OR REPLACE VIEW v_pricing_canonico_confrontabili AS
SELECT * FROM v_pricing_canonico
WHERE n_competitors >= 2;
 
CREATE OR REPLACE VIEW v_gap_competitivo AS
SELECT
    canonical_id,
    display_name,
    gioco,
    set_canonico,
    tipologia,
    variant,
    n_competitors,
 
    -- Prezzo USD tax-excluded: min, max, media tra i competitor che lo trattano
    LEAST(
        IFNULL(price_mm_usd_net,  999999),
        IFNULL(price_csi_usd_net, 999999),
        IFNULL(price_icn_usd_net, 999999)
    ) AS prezzo_min_usd,
    GREATEST(
        IFNULL(price_mm_usd_net,  0),
        IFNULL(price_csi_usd_net, 0),
        IFNULL(price_icn_usd_net, 0)
    ) AS prezzo_max_usd,
    ROUND((
        IFNULL(price_mm_usd_net,  0) +
        IFNULL(price_csi_usd_net, 0) +
        IFNULL(price_icn_usd_net, 0)
    ) / NULLIF(
        (price_mm_usd_net  IS NOT NULL) +
        (price_csi_usd_net IS NOT NULL) +
        (price_icn_usd_net IS NOT NULL), 0
    ), 2) AS prezzo_medio_usd,
 
    -- Gap assoluto in USD
    ROUND(
        GREATEST(IFNULL(price_mm_usd_net,0), IFNULL(price_csi_usd_net,0), IFNULL(price_icn_usd_net,0))
        - LEAST(IFNULL(price_mm_usd_net,999999), IFNULL(price_csi_usd_net,999999), IFNULL(price_icn_usd_net,999999))
    , 2) AS gap_assoluto_usd,
 
    -- Gap percentuale (rispetto al prezzo minimo)
    ROUND(100 * (
        GREATEST(IFNULL(price_mm_usd_net,0), IFNULL(price_csi_usd_net,0), IFNULL(price_icn_usd_net,0))
        - LEAST(IFNULL(price_mm_usd_net,999999), IFNULL(price_csi_usd_net,999999), IFNULL(price_icn_usd_net,999999))
    ) / NULLIF(LEAST(IFNULL(price_mm_usd_net,999999), IFNULL(price_csi_usd_net,999999), IFNULL(price_icn_usd_net,999999)), 0), 1) AS gap_percentuale,
 
    -- Competitor con il prezzo più basso
    CASE
        WHEN price_mm_usd_net  = LEAST(IFNULL(price_mm_usd_net,999999), IFNULL(price_csi_usd_net,999999), IFNULL(price_icn_usd_net,999999)) THEN 'Miniature Market'
        WHEN price_csi_usd_net = LEAST(IFNULL(price_mm_usd_net,999999), IFNULL(price_csi_usd_net,999999), IFNULL(price_icn_usd_net,999999)) THEN 'CoolStuffInc'
        WHEN price_icn_usd_net = LEAST(IFNULL(price_mm_usd_net,999999), IFNULL(price_csi_usd_net,999999), IFNULL(price_icn_usd_net,999999)) THEN 'Il Covo del Nerd'
    END AS competitor_piu_economico,
 
    price_mm_usd_net,
    price_csi_usd_net,
    price_icn_usd_net
 
FROM v_pricing_canonico
WHERE n_competitors >= 2;
 
CREATE OR REPLACE VIEW v_catalog_depth AS
SELECT
    c.name AS competitor,
    c.market_region,
    g.name AS gioco,
 
    COUNT(DISTINCT p.id) AS n_prodotti_totali,
    COUNT(DISTINCT CASE WHEN po.listing_status = 'active'   THEN p.id END) AS n_prodotti_attivi,
    COUNT(DISTINCT CASE WHEN po.listing_status = 'inactive' THEN p.id END) AS n_prodotti_inattivi,
 
    COUNT(DISTINCT s.id)  AS n_set_coperti,
    COUNT(DISTINCT pt.id) AS n_tipologie_coperte,
    COUNT(DISTINCT cp.id) AS n_canonical_coperti,
 
    -- Statistiche prezzo (solo prodotti attivi, in valuta nativa)
    ROUND(AVG(CASE WHEN po.listing_status = 'active' THEN po.price END), 2) AS prezzo_medio,
    ROUND(MIN(CASE WHEN po.listing_status = 'active' THEN po.price END), 2) AS prezzo_minimo,
    ROUND(MAX(CASE WHEN po.listing_status = 'active' THEN po.price END), 2) AS prezzo_massimo,
    MAX(po.currency) AS valuta
 
FROM products p
JOIN competitors c  ON p.competitor_id = c.id
JOIN price_observations po ON po.product_id = p.id
LEFT JOIN sets s   ON p.set_id = s.id
LEFT JOIN tcg_games g ON s.tcg_game_id = g.id
LEFT JOIN product_types pt ON p.product_type_id = pt.id
LEFT JOIN canonical_products cp ON p.canonical_product_id = cp.id
WHERE g.name IS NOT NULL
GROUP BY c.name, c.market_region, g.name;
 
CREATE OR REPLACE VIEW v_price_tier AS
SELECT
    p.id AS product_id,
    p.name AS product_name,
    c.name AS competitor,
    g.name AS gioco,
    pt.name AS tipologia,
    cp.display_name AS canonical,
 
    po.price    AS prezzo_originale,
    po.currency AS valuta,
 
    -- Prezzo USD tax-excluded
    CASE
        WHEN po.currency = 'USD' THEN po.price
        WHEN po.currency = 'EUR' THEN ROUND(po.price / 1.22 * 1.13, 2)
    END AS prezzo_usd_net,
 
    -- Fascia di prezzo
    CASE
        WHEN (CASE WHEN po.currency='USD' THEN po.price ELSE po.price/1.22*1.13 END) <  25  THEN '1. Entry (<$25)'
        WHEN (CASE WHEN po.currency='USD' THEN po.price ELSE po.price/1.22*1.13 END) <  75  THEN '2. Mid ($25-75)'
        WHEN (CASE WHEN po.currency='USD' THEN po.price ELSE po.price/1.22*1.13 END) < 150  THEN '3. Premium ($75-150)'
        WHEN (CASE WHEN po.currency='USD' THEN po.price ELSE po.price/1.22*1.13 END) < 300  THEN '4. High-end ($150-300)'
        ELSE '5. Luxury (>$300)'
    END AS price_tier
 
FROM products p
JOIN competitors c  ON p.competitor_id = c.id
JOIN price_observations po ON po.product_id = p.id
JOIN product_types pt ON p.product_type_id = pt.id
LEFT JOIN canonical_products cp ON p.canonical_product_id = cp.id
LEFT JOIN sets s   ON p.set_id = s.id
LEFT JOIN tcg_games g ON s.tcg_game_id = g.id
WHERE po.price IS NOT NULL
  AND g.name IS NOT NULL;
 
CREATE OR REPLACE VIEW v_market_overview AS
SELECT
    g.name AS gioco,
    c.name AS competitor,
    c.market_region,
 
    COUNT(DISTINCT p.id)  AS n_prodotti,
    COUNT(DISTINCT s.id)  AS n_set,
    COUNT(DISTINCT cp.id) AS n_canonical,
 
    -- Prezzi in valuta nativa
    ROUND(AVG(po.price), 2) AS prezzo_medio_nativo,
    MAX(po.currency) AS valuta_nativa,
 
    -- Prezzi in USD tax-excluded
    ROUND(AVG(
        CASE
            WHEN po.currency = 'USD' THEN po.price
            WHEN po.currency = 'EUR' THEN po.price / 1.22 * 1.13
        END
    ), 2) AS prezzo_medio_usd_net,
 
    ROUND(MIN(
        CASE
            WHEN po.currency = 'USD' THEN po.price
            WHEN po.currency = 'EUR' THEN po.price / 1.22 * 1.13
        END
    ), 2) AS prezzo_min_usd_net,
 
    ROUND(MAX(
        CASE
            WHEN po.currency = 'USD' THEN po.price
            WHEN po.currency = 'EUR' THEN po.price / 1.22 * 1.13
        END
    ), 2) AS prezzo_max_usd_net,
 
    -- Listing status (attivi vs inattivi)
    SUM(CASE WHEN po.listing_status = 'active'   THEN 1 ELSE 0 END) AS n_attivi,
    SUM(CASE WHEN po.listing_status = 'inactive' THEN 1 ELSE 0 END) AS n_inattivi,
    ROUND(100 * SUM(CASE WHEN po.listing_status = 'active' THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_attivi
 
FROM products p
JOIN competitors c  ON p.competitor_id = c.id
JOIN price_observations po ON po.product_id = p.id
LEFT JOIN sets s   ON p.set_id = s.id
LEFT JOIN tcg_games g ON s.tcg_game_id = g.id
LEFT JOIN canonical_products cp ON p.canonical_product_id = cp.id
WHERE po.price IS NOT NULL
  AND g.name IS NOT NULL
GROUP BY g.name, c.name, c.market_region;

CREATE OR REPLACE VIEW v_savings_opportunity AS
SELECT
    canonical_id,
    display_name,
    gioco,
    set_canonico,
    tipologia,
    competitor_piu_economico,
    prezzo_min_usd,
    prezzo_max_usd,
    gap_assoluto_usd AS risparmio_assoluto_usd,
    gap_percentuale  AS risparmio_percentuale,
    n_competitors
FROM v_gap_competitivo
WHERE prezzo_min_usd > 0
  AND prezzo_max_usd > 0
  AND gap_percentuale IS NOT NULL;
 
 

 SHOW TABLES;
SELECT * FROM competitors;
SELECT * FROM tcg_games;
SELECT * FROM product_types;
 
-- Conteggi righe per vista
SELECT 'v_pricing_canonico'                AS vista, COUNT(*) AS righe FROM v_pricing_canonico
UNION ALL SELECT 'v_pricing_canonico_confrontabili', COUNT(*) FROM v_pricing_canonico_confrontabili
UNION ALL SELECT 'v_gap_competitivo',                COUNT(*) FROM v_gap_competitivo
UNION ALL SELECT 'v_catalog_depth',                  COUNT(*) FROM v_catalog_depth
UNION ALL SELECT 'v_price_tier',                     COUNT(*) FROM v_price_tier
UNION ALL SELECT 'v_market_overview',                COUNT(*) FROM v_market_overview
UNION ALL SELECT 'v_savings_opportunity',            COUNT(*) FROM v_savings_opportunity;